package com.uas.pi;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAccessor;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.ParticipantBean;
import com.uas.bean.ProgramsOfferedBean;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.bean.UserBean;
import com.uas.bean.UserRole;
import com.uas.exception.UserException;
import com.uas.service.AdminServiceImpl;
import com.uas.service.ApplicantServiceImpl;
import com.uas.service.IMacService;
import com.uas.service.IParticipantService;
import com.uas.service.MacServiceImpl;
import com.uas.service.ParticipantServiceImpl;

/**
 *  Author : KAMAL, GUNJAN
 *  Class Name : Client 
 *  Package :com.uas.pi 
 *  Date : December 18, 2017
 *  Version : 1.3.2
 */
public class Client {

	private static Logger logger = Logger.getRootLogger();
	static Scanner input = new Scanner(System.in);
	static ApplicantServiceImpl applicantService = new ApplicantServiceImpl();
	static AdminServiceImpl adminService = new AdminServiceImpl();
	static IMacService macService = new MacServiceImpl();
	static IParticipantService participantService = new ParticipantServiceImpl();

	public static void main(String[] args) {

		PropertyConfigurator.configure("resources/log4j.properties");
		UserBean user = new UserBean();

		System.out.println("University Management System");
		System.out.println("=====================================");
		System.out.println("Enter Your Role:");
		System.out.println("1. Admin");
		System.out.println("2. Member of Admission Committee");
		System.out.println("3. Applicant");
		System.out.println("4. Exit");
		int choice = Integer.parseInt(input.nextLine());
		
		switch (choice) {

		case 1:
			System.out.println("Enter Login ID: ");
			user.setLoginId(input.nextLine());
			System.out.println("Enter Password: ");
			user.setPassword(input.nextLine());
			user.setRole(UserRole.ADMIN);
			try {

				if (adminService.isAuthenticated(user)) {
					logger.info("Login as Admin");
					loginAsAdmin();
				} else {
					System.out.println("Enter valid credentials");
					logger.error("Enter valid credentials");
				}
			} catch (UserException e) {
				System.out.println(e.getMessage());
				logger.error(e.getMessage());
			}
			break;

		case 2:
			System.out.println("Enter Login ID: ");
			user.setLoginId(input.nextLine());
			System.out.println("Enter Password: ");
			user.setPassword(input.nextLine());
			user.setRole(UserRole.MAC);
			try {
				if (macService.isAuthenticated(user)) {
					logger.info("Login as Member of Admission Committee");
					loginAsMAC();
				} else {
					System.out.println("Enter valid credentials");
					logger.error("Enter Valid Credentials");
				}
			} catch (UserException e) {
				System.out.println(e.getMessage());
				logger.error(e.getMessage());
			}
			break;

		case 3:
			logger.info("Entered as Applicant");
			loginAsApplicant();
			break;
		case 4:
			System.out.println("You are out of the University Admission System");
			break;
		default:
			System.out.println("Enter valid option");
			break;
		}
	}

	public static void loginAsAdmin() {
		System.out.println("Enter Choice");
		System.out.println("1. Programs Offered");
		System.out.println("2. Programs Scheduled");
		System.out.println("3. View Reports");
		int choice = Integer.parseInt(input.nextLine());

		switch (choice) {

		case 1:
			programsOffered();
			break;

		case 2:
			programsSchedule();
			break;

		case 3:
			viewReports();
			break;
		default:
			System.out.println("Enter valid option");
			logger.error("Enter valid option");
		}
	}

	public static void programsOffered() {
		System.out.println("Enter choice");
		System.out.println("1. Add Program Offered");
		System.out.println("2. Delete Program Offered");
		int response = Integer.parseInt(input.nextLine());
		if (response == 1)
			addProgramOffered();
		else if (response == 2)
			deleteProgramOffered();
		else {
			logger.error("Enter valid option");
			System.out.println("Enter valid option");
		}
	}

	public static void addProgramOffered() {

		boolean isValid = false;

		ProgramsOfferedBean programsOfferedBean = new ProgramsOfferedBean();
		while (!isValid) {
			try {
				System.out.println("Enter program name");
				String programName = input.nextLine();
				isValid = adminService.isValidProgramName(programName);
				if (isValid) {
					programsOfferedBean.setProgramName(programName);
				}
			} catch (UserException e) {
				System.out.println(e.getMessage());
				isValid = false;
			}
		}
		isValid = false;
		while (!isValid) {
			try {
				System.out.println("Enter program description");
				String description = input.nextLine();
				isValid = adminService.isValidDescription(description);
				if (isValid)
					programsOfferedBean.setDescription(description);
			} catch (UserException e) {
				System.out.println(e.getMessage());
				isValid = false;
			}
		}
		isValid = false;
		while (!isValid) {
			try {
				System.out.println("Enter applicant eligibility");
				String eligibility = input.nextLine();
				isValid = adminService.isValidEligibility(eligibility);
				if (isValid)
					programsOfferedBean.setApplicantEligibility(eligibility);
			} catch (UserException e) {
				System.out.println(e.getMessage());
				isValid = false;
			}
		}
		isValid = false;
		while (!isValid) {
			try {
				System.out.println("Enter degree offered");
				String degreeOffered = input.nextLine();
				isValid = adminService.isValidDegreeOffered(degreeOffered);
				if (isValid)
					programsOfferedBean.setDegreeOffered(degreeOffered);
			} catch (UserException e) {
				System.out.println(e.getMessage());
				isValid = false;
			}
		}
		isValid = false;
		while (!isValid) {
			try {
				System.out.println("Duration in weeks");
				byte weeks = input.nextByte();
				isValid = adminService.isValidDuration(weeks);
				if (isValid)
					programsOfferedBean.setDuration(weeks);
			} catch (UserException e) {
				System.out.println(e.getMessage());
				isValid = false;
			}
		}
		try {
			boolean isAdded = adminService
					.addProgramOffered(programsOfferedBean);
			if (isAdded) {
				logger.info(programsOfferedBean);
				logger.info("Program Offered Added Successfully!");
				System.out.println("Program Offered Added Successfully!");
			}
		} catch (UserException e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());
		}
	}

	public static void deleteProgramOffered() {
		System.out.println("Enter program name");
		String programName = input.next();
		try {
			boolean isDeleted = adminService.deleteProgramOffered(programName);
			if (isDeleted) {
				logger.info("Program Offered" + programName
						+ "Deleted Successfully!");
				System.out.println("Program Offered " + programName
						+ "Deleted Successfully!");
			}
		} catch (UserException e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());
		}
	}

	public static void programsSchedule() {
		System.out.println("Enter choice");
		System.out.println("1. Add Program Schedule");
		System.out.println("2. Delete Program Schedule");
		switch (input.nextInt()) {
		case 1:
			addProgramsScheduled();
			break;
		case 2:
			deleteProgramsScheduled();
			break;
		default:
			logger.error("Enter valid option");
			System.out.println("Enter valid option");
		}
	}

	public static void addProgramsScheduled() {

		boolean isValid = false;
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter
				.ofPattern("dd/MM/yyyy");

		ProgramsScheduledBean programsScheduledBean = new ProgramsScheduledBean();
		ProgramsOfferedBean programsOfferedBean = new ProgramsOfferedBean();

		while (!isValid) {
			try {
				System.out.println("Enter program ID to be scheduled");
				String programId = input.next();
				isValid = adminService.checkValidProgramId(programId);
				if (isValid)
					programsScheduledBean.setProgramId(programId);
			} catch (UserException e) {
				System.out.println(e.getMessage());
				isValid = false;
			}
		}
		isValid = false;
		while (!isValid) {
			try {
				System.out.println("Enter program name");
				String programName = input.next();
				isValid = adminService.isValidProgramName(programName);
				if (isValid) {
					programsOfferedBean.setProgramName(programName);
					programsScheduledBean
							.setProgramsOfferedBean(programsOfferedBean);
				}
			} catch (UserException e) {
				System.out.println(e.getMessage());
				isValid = false;
			}
		}
		isValid = false;
		while (!isValid) {
			try {
				System.out
						.println("Enter city where program is to be scheduled ");
				String city = input.next();
				isValid = adminService.checkValidCity(city);
				if (isValid)
					programsScheduledBean.setCity(city);
			} catch (UserException e) {
				System.out.println(e.getMessage());
				isValid = false;
			}
		}
		isValid = false;
		while (!isValid) {
			try {
				System.out.println("Enter state");
				String state = input.next();
				input.nextLine();
				isValid = adminService.checkValidState(state);
				if (isValid)
					programsScheduledBean.setState(state);
			} catch (UserException e) {
				System.out.println(e.getMessage());
				isValid = false;
			}
		}
		isValid = false;
		while (!isValid) {
			try {
				System.out.println("Enter ZipCode");
				int zipCode = input.nextInt();
				isValid=adminService.checkValidZipcode(zipCode);
				if(isValid)
					programsScheduledBean.setZipCode(zipCode);
			}catch (UserException e) {
				System.out.println(e.getMessage());
				isValid = false;
			}
		}
		
		isValid = false;
		while (!isValid) {
			try {
				System.out.println("Enter Start Date");
				TemporalAccessor temporalAccessor = dateTimeFormatter.parse(input
						.next());
				programsScheduledBean.setStartDate(LocalDate.from(temporalAccessor));
				isValid=true;
			}catch(java.time.format.DateTimeParseException e){
				System.out.println("Enter date in required format");
				isValid=false;
			}
		}
		isValid = false;
		while (!isValid) {
			try {
				System.out.println("Enter End Date");
				TemporalAccessor temporalAccessor = dateTimeFormatter.parse(input.next());
				programsScheduledBean.setEndDate(LocalDate.from(temporalAccessor));
				isValid=true;
			}catch(java.time.format.DateTimeParseException e){
				System.out.println("Enter date in required format");
				isValid=false;
			}
		}
		
		isValid = false;
		while (!isValid) {
			try {
					System.out.println("Enter session per week");
					byte week = input.nextByte();
					isValid=adminService.checkValidSession(week);
					if(isValid)
						programsScheduledBean.setSessionPerWeek(week);
			}catch (UserException e) {
				System.out.println(e.getMessage());
				isValid = false;
			}
		}
		try {
			boolean isAdded = adminService
					.addProgramScheduled(programsScheduledBean);
			if (isAdded) {
				logger.info(programsScheduledBean);
				logger.info("Program Scheduled Added Successfully!");
				System.out.println("Program Scheduled Added Successfully!");
			}
		} catch (UserException e) {
			logger.info(e.getMessage());
			System.out.println(e.getMessage());
		}
	}

	public static void deleteProgramsScheduled() {
		System.out.println("Enter program ID");
		String programId = input.next();
		try {
			boolean isDeleted = adminService.deleteProgramScheduled(programId);
			if (isDeleted) {
				logger.info("Program Scheduled with program ID : " + programId
						+ "is Deleted Succesfully!");
				System.out.println("Program Scheduled with program ID : "
						+ programId + "is Deleted Succesfully!");
			}
		} catch (UserException e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());
		}
	}

	public static void viewReports() {
		System.out.println("Enter choice");
		System.out.println("1. View Applicants");
		System.out.println("2. View Programs");
		switch (input.nextInt()) {
		case 1:
			viewApplicants();
			break;
		case 2:
			viewScheduledPrograms();
			break;
		default:
			logger.error("Enter valid option");
			System.out.println("Enter valid option");
		}
	}

	private static void viewScheduledPrograms() {
		try {
			List<ProgramsScheduledBean> programsScheduledList = adminService
					.viewProgramsScheduled();
			for (ProgramsScheduledBean programsScheduledBean : programsScheduledList) {
				logger.info(programsScheduledBean);
				System.out.println(programsScheduledBean);
			}
		} catch (UserException e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());
		}
	}

	public static void viewApplicants() {
		try {
			List<ApplicantBean> applicantList = adminService
					.viewListOfApplicants();
			for (ApplicantBean applicantBean : applicantList) {
				System.out.println("==================================");
				System.out.println(applicantBean);
				logger.info(applicantBean);
			}
		} catch (UserException e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());
		}
	}

	public static void viewPrograms() {

		try {
			List<ProgramsScheduledBean> programList = applicantService
					.viewPrograms();
			for (ProgramsScheduledBean programsScheduledBean : programList) {
				System.out.println(programsScheduledBean);
				logger.info(programsScheduledBean);
			}
		} catch (UserException e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());
		}
	}

	public static void loginAsMAC() {
		System.out.println("Enter choice");
		System.out.println("1. View Applicants");
		System.out.println("2. Accepted/Rejected Application");
		System.out.println("3. Confirmed/Rejected Application");
		switch (input.nextInt()) {
		case 1:
			viewSpecificApplicants();
			break;
		case 2:
			updateInterviewDate();
			break;
		case 3:
			updateApplicationStatus();
			break;
		default:
			logger.error("Enter valid option");
			System.out.println("Enter valid option");
		}
	}

	private static void updateInterviewDate() {
		boolean isValid = false;

		System.out.println("Enter application id");
		int applicationId = input.nextInt();
		System.out.println("Enter status of applicant");
		Application_Status status = null;
		while (!isValid) {
			try {
				status = Application_Status.valueOf(input.next().toUpperCase());
				isValid = true;
			} catch (java.lang.IllegalArgumentException e) {
				System.out.println("Enter either Accepted or Rejected");
				isValid = false;
			}
		}

		LocalDate dateOfInterview = null;
		if (status != Application_Status.REJECTED) {
			DateTimeFormatter dateTimeFormatter = DateTimeFormatter
					.ofPattern("dd/MM/yyyy");
			System.out.println("Enter date of interview (dd/MM/yyyy)");
			TemporalAccessor temporalAccessor = dateTimeFormatter.parse(input
					.next());
			dateOfInterview = LocalDate.from(temporalAccessor);
		}
		try {
			boolean isUpdated = macService.scheduleInterviewDate(applicationId,
					status, dateOfInterview);
			if (isUpdated) {
				if (dateOfInterview != null) {
					logger.info("Applicant status updated. Participant enrolled for Interview. The date is "
							+ dateOfInterview);
					System.out
							.println("Applicant status updated. Participant enrolled for Interview.  The date is "
									+ dateOfInterview);
				} else {
					logger.info("Applicant status updated.");
					System.out.println("Applicant status updated.");
				}
			}
		} catch (UserException e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());
		}
	}

	private static void viewSpecificApplicants() {
		System.out.println("Enter Program Scheduled ID");
		try {
			List<ApplicantBean> applicantList = macService
					.viewAllStudentDetails(input.next());
			for (ApplicantBean applicantBean : applicantList) {
				System.out.println(applicantBean);
				logger.info(applicantBean);
			}
		} catch (UserException e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());
		}
	}

	public static void updateApplicationStatus() {

		boolean isValid = false;

		System.out.println("Enter application id");
		int applicationId = input.nextInt();
		System.out.println("Enter status of applicant");
		Application_Status status = null;
		while (!isValid) {
			try {
				status = Application_Status.valueOf(input.next().toUpperCase());
				isValid = true;
			} catch (java.lang.IllegalArgumentException e) {
				System.out.println("Enter either confirmed or Rejected");
				isValid = false;
			}
		}
		System.out.println(status);
		try {
			if (status == Application_Status.CONFIRMED) {
				String rollNo = Integer.toString(applicationId);
				String[] info = applicantService
						.getApplicantInfo(applicationId);
				ParticipantBean participantBean = new ParticipantBean(rollNo,
						info[0]);

				boolean isInserted = participantService.addParticipant(
						participantBean, applicationId,
						info[1]);

				if (isInserted) {
					logger.info("Enrolled Successfully");
					System.out.println("Enrolled successfully");
				}
			}// end outer if
			boolean isUpdated = macService.enrollApplicant(applicationId,
					status);
			if (isUpdated) {
				logger.info("Status Updated");
				System.out.println("Status Updated");
			}
		} catch (UserException e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());
		}

		System.out.println();
	}

	public static void loginAsApplicant() {
		System.out.println("Enter choice");
		System.out.println("1. View Applied Program Status");
		System.out.println("2. View Programs");
		switch (input.nextInt()) {
		case 1:
			System.out.println("Enter your Application ID: ");
			int applicantId = Integer.parseInt(input.next());
			viewAppliedProgramStatus(applicantId);
			break;
		case 2:
			viewPrograms();
			ApplicantBean applicantBean = new ApplicantBean();
			try {
				String programName = populateApplicantBean(applicantBean);
				int applicantID = applicantService.insertApplicant(
						applicantBean, programName);
				logger.info(applicantBean + " for program " + programName);
				logger.info("Applicant added succesfully with applicant ID: "
						+ applicantID);
				System.out.println("Your Applicant ID is: " + applicantID);
			} catch (UserException e) {
				logger.error(e.getMessage());
				System.out.println(e.getMessage());
			}
			break;
		default:
			logger.error("Enter valid option");
			System.out.println("Enter valid option");
		}
	}

	public static void viewAppliedProgramStatus(int applicantId) {
		try {
			Application_Status status = applicantService
					.viewStatus(applicantId);
			logger.info("For Applicant ID: " + applicantId + " status is "
					+ status);
			System.out.println("Your status is: " + status);
		} catch (UserException e) {
			logger.error(e.getMessage());
			System.out.println(e.getMessage());
		}
	}

	public static String populateApplicantBean(ApplicantBean applicantBean) {

		boolean isValid = false;
		DateTimeFormatter dateTimeFormatter = DateTimeFormatter
				.ofPattern("dd/MM/yyyy");

		isValid = false;
		while (!isValid) {
			try {
				System.out.println("Enter full name");
				String applicantName = input.next();
				isValid = applicantService.isValidName(applicantName);
				if (isValid) {
					applicantBean.setFullName(applicantName);
				}
			} catch (UserException e) {
				logger.error(e.getMessage());
				System.out.println(e.getMessage());
				isValid = false;
			}
		}
		isValid = false;
		while (!isValid) {
			try {
				System.out.println("Enter date of birth (dd/mm/yyyy)");
				TemporalAccessor temporalAccessor = dateTimeFormatter
						.parse(input.next());
				applicantBean.setDateOfBirth(LocalDate.from(temporalAccessor));
				isValid = true;
			} catch (java.time.format.DateTimeParseException e) {
				logger.error("Enter Date in specified format");
				System.out.println("Enter Date in specified format");
				isValid = false;
			}
		}
		System.out.println("Enter highest qualification");
		applicantBean.setHighestQualification(input.next());
		isValid = false;
		while (!isValid) {
			try {
				System.out.println("Enter marks obtained");
				int marksObtained = input.nextInt();
				isValid = applicantService.isValidMarksObtained(marksObtained);
				if (isValid) {
					applicantBean.setMarksObtained(marksObtained);
				}
			} catch (UserException e) {
				logger.error(e.getMessage());
				System.out.println(e.getMessage());
				isValid = false;
			}
		}
		System.out.println("Enter your Goals");
		applicantBean.setGoals(input.next());
		isValid = false;
		while (!isValid) {
			try {
				System.out.println("Enter email id");
				String emailId = input.next();
				isValid = applicantService.isValidMail(emailId);
				if (isValid) {
					applicantBean.setEmailId(emailId);
				}
			} catch (UserException e) {
				logger.error(e.getMessage());
				System.out.println(e.getMessage());
				isValid = false;
			}
		}
		System.out.println("Enter program name");
		String programName = input.next();
		logger.info("Applicant Created " + applicantBean);
		return programName;
	}
}