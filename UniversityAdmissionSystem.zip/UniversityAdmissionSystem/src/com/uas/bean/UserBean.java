package com.uas.bean;

/**
 * Author 		: KAMAL, GUNJAN 
 * Class Name 	: UserBean 
 * Package 		: com.uas.bean 
 * Date 		: November 27, 2017
 * Version		: 1.1
 */
public class UserBean {
	private String loginId;
	private String password;
	private UserRole role;
	
	//Constructors
	public UserBean() {
		super();
	}
	
	public UserBean(String loginId, String password, UserRole role) {
		super();
		this.loginId = loginId;
		this.password = password;
		this.role = role;
	}
	
	//Getters and Setters
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public UserRole getRole() {
		return role;
	}
	public void setRole(UserRole role) {
		this.role = role;
	}
	
	//toString
	@Override
	public String toString() {
		return "User Details "
				+ "\n Login Id = " + loginId 
				+ "\n Password = " + password
				+ "\n Role = " + role;
	}
	
}