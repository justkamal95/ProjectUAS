package com.uas.bean;

/**
 * Author 		: KAMAL, GUNJAN 
 * Enum Name 	: UserRole 
 * Package 		: com.uas.bean 
 * Date 		: November 27, 2017
 * Version		: 1.0
 */
public enum UserRole{
	ADMIN, MAC, APPLICANT;	
}
