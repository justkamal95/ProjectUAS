package com.uas.bean;

import java.time.LocalDate;

/**
 * Author 		: KAMAL, GUNJAN 
 * Class Name 	: ApplicantBean 
 * Package 		: com.uas.bean 
 * Date 		: November 27, 2017
 * Version		: 1.1
 */

public class ApplicantBean {
	private int applicationId;
	private String fullName;
	private LocalDate dateOfBirth;
	private String highestQualification;
	private int marksObtained;
	private String goals;
	private String emailId;
	private ProgramsScheduledBean programsScheduledBean;
	private Application_Status status;
	private LocalDate dateOfInterview;
	
	//Constructors
	public ApplicantBean() {
		super();
	}
	public ApplicantBean(String fullName,
			LocalDate dateOfBirth, String highestQualification,
			int marksObtained, String goals, String emailId,
			ProgramsScheduledBean programsScheduledBean,
			Application_Status status, LocalDate dateOfInterview) {
		super();
		this.fullName = fullName;
		this.dateOfBirth = dateOfBirth;
		this.highestQualification = highestQualification;
		this.marksObtained = marksObtained;
		this.goals = goals;
		this.emailId = emailId;
		this.programsScheduledBean = programsScheduledBean;
		this.status = status;
		this.dateOfInterview = dateOfInterview;
	}
	
	//Getters and Setters
	public int getApplicationId() {
		return applicationId;
	}
	public void setApplicationId(int applicationId) {
		this.applicationId = applicationId;
	}
	public String getFullName() {
		return fullName;
	}
	public void setFullName(String fullName) {
		this.fullName = fullName;
	}
	public LocalDate getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(LocalDate dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}
	public String getHighestQualification() {
		return highestQualification;
	}
	public void setHighestQualification(String highestQualification) {
		this.highestQualification = highestQualification;
	}
	public int getMarksObtained() {
		return marksObtained;
	}
	public void setMarksObtained(int marksObtained) {
		this.marksObtained = marksObtained;
	}
	public String getGoals() {
		return goals;
	}
	public void setGoals(String goals) {
		this.goals = goals;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public ProgramsScheduledBean getProgramsScheduledBean() {
		return programsScheduledBean;
	}
	public void setProgramsScheduledBean(ProgramsScheduledBean programsScheduledBean) {
		this.programsScheduledBean = programsScheduledBean;
	}
	public Application_Status getStatus() {
		return status;
	}
	public void setStatus(Application_Status status) {
		this.status = status;
	}
	public LocalDate getDateOfInterview() {
		return dateOfInterview;
	}
	public void setDateOfInterview(LocalDate dateOfInterview) {
		this.dateOfInterview = dateOfInterview;
	}
	
	//toString
	@Override
	public String toString() {
		return "===================================================="
				+ "\n Applicant Details:\nApplication Id = " + applicationId 
				+ "\n Full Name = "+ fullName 
				+ "\n Date Of Birth = " + dateOfBirth
				+ "\n Highest Qualification = " + highestQualification
				+ "\n Marks Obtained = " + marksObtained 
				+ "\n Goals = " + goals
				+ "\n Email-Id = " + emailId 
				+ "\n Applicant Program ID:\n "+ programsScheduledBean.getProgramId()
				+ "\n Status = " + status
				+ "\n Date Of Interview = " + dateOfInterview;
	}
	
	
	
	
}