package com.uas.bean;

/**
 * Author 		: KAMAL, GUNJAN 
 * Class Name 	: ParticipantBean 
 * Package 		: com.uas.bean 
 * Date 		: November 27, 2017
 * Version		: 1.1
 */
public class ParticipantBean {
	private String rollNo;
	private String emailId;
	private ApplicantBean applicantBean;
	private ProgramsScheduledBean programsScheduledBean;
	
	//Constructors
	public ParticipantBean() {
		super();
	}
	
	public ParticipantBean(String rollNo, String emailId) {
		super();
		this.rollNo = rollNo;
		this.emailId = emailId;
	}

	public ParticipantBean(String rollNo, String emailId,
			ApplicantBean applicantBean,
			ProgramsScheduledBean programsScheduledBean) {
		super();
		this.rollNo = rollNo;
		this.emailId = emailId;
		this.applicantBean = applicantBean;
		this.programsScheduledBean = programsScheduledBean;
	}

	//Getters and Setters
	public String getRollNo() {
		return rollNo;
	}

	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public ApplicantBean getApplicantBean() {
		return applicantBean;
	}

	public void setApplicantBean(ApplicantBean applicantBean) {
		this.applicantBean = applicantBean;
	}

	public ProgramsScheduledBean getProgramsScheduledBean() {
		return programsScheduledBean;
	}

	public void setProgramsScheduledBean(ProgramsScheduledBean programsScheduledBean) {
		this.programsScheduledBean = programsScheduledBean;
	}

	//toString
	@Override
	public String toString() {
		return "Participant Details:"
				+ "\nRoll No = " + rollNo 
				+ "\n Email-Id = " + emailId
				+ "\n" + applicantBean
				+ "\n" + programsScheduledBean;
	}
	
	
}
