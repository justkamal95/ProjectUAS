package com.uas.bean;

/**
 * Author 		: KAMAL, GUNJAN 
 * Bean Name 	: Application_Status 
 * Package 		: com.uas.bean 
 * Date 		: November 27, 2017
 * Version		: 1.0
 */
public enum Application_Status{
	APPLIED, ACCEPTED, REJECTED, CONFIRMED;
}
