package com.uas.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.dao.ApplicantDAOImpl;
import com.uas.dao.IApplicantDAO;
import com.uas.exception.UserException;

/**
 * Author 		: KAMAL, GUNJAN 
 * Class Name 	: ApplicantServiceImpl 
 * Package 		: com.uas.service 
 * Date 		: December 09, 2017
 * Version : 1.0
 */
public class ApplicantServiceImpl implements IApplicantService {

	private IApplicantDAO applicantDAO;	
	
	public ApplicantServiceImpl() {
		applicantDAO = new ApplicantDAOImpl();
	}

	/**************************************************************
	 * - Method Name : viewPrograms() 
	 * - Input Parameters :  
	 * - Return Type :List<ProgramsScheduledBean> 
	 * - Throws : UserException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieval of programs offered along with programs scheduled
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public List<ProgramsScheduledBean> viewPrograms() throws UserException {
		List<ProgramsScheduledBean> programsList =  applicantDAO.viewPrograms();
		return programsList;
	}

	/**************************************************************
	 * - Method Name : insertApplicant(ApplicantBean applicantBean,String programName) 
	 * - Input Parameters :  ApplicantBean, String
	 * - Return Type :int 
	 * - Throws : UserException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 09, 2017 
	 * - Description : insert new applicant details
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public int insertApplicant(ApplicantBean applicantBean, String programName) throws UserException {
		int applicantId = applicantDAO.insertApplicant(applicantBean, programName);
		return applicantId;
	}

	/**************************************************************
	 * - Method Name : viewStatus(int applicantId) 
	 * - Input Parameters :  int
	 * - Return Type :Application_Status 
	 * - Throws : UserException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieval of status of an applicant according to applicantId
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public Application_Status viewStatus(int applicantId) throws UserException {
		Application_Status status = applicantDAO.viewStatus(applicantId);
		return status;
	}
	
	/**************************************************************
	 * - Method Name : isValidName(String name) 
	 * - Input Parameters : String name
	 * - Return Type :boolean 
	 * - Throws : UserException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 16, 2017 
	 * - Description : Validating applicant name
	 * - Version : 1.0
	 *************************************************************/
	public boolean isValidName(String name) throws UserException{
		boolean isValid = false;
		String pattern = "[A-Z]{1}[A-Za-z]{1,19}";		
		Pattern ptn = Pattern.compile(pattern);
		Matcher matcher = ptn.matcher(name);
		isValid = matcher.matches();
		if(!isValid){
			throw new UserException("First Character should be capital followed by maximum 20 characters");
		}
		return isValid;
	}

	/**************************************************************
	 * - Method Name : isValidMarksObtained(int marks)
	 * - Input Parameters : int marks
	 * - Return Type :boolean 
	 * - Throws : UserException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 16, 2017 
	 * - Description : Validating applicant marks
	 * - Version : 1.0
	 *************************************************************/
	public boolean isValidMarksObtained(int marks) throws UserException{
		boolean isValid = true;
		if(marks<=0){
			throw new UserException("Marks Should be a positive integer");
		}
		return isValid;
	}
	
	/**************************************************************
	 * - Method Name : isValidMail(String mail)
	 * - Input Parameters : String mail
	 * - Return Type :boolean 
	 * - Throws : UserException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 16, 2017 
	 * - Description : Validating applicant email ID
	 * - Version : 1.0
	 *************************************************************/
	public boolean isValidMail(String mail) throws UserException{
		boolean isValid = false;
		String pattern = "[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$";		
		Pattern ptn = Pattern.compile(pattern);
		Matcher matcher = ptn.matcher(mail);
		isValid = matcher.matches();
		if(!isValid){
			throw new UserException("Invalid Email ID");
		}
		return isValid;
	}
	
	/**************************************************************
	 * - Method Name : getApplicantInfo(int applicationId) 
	 * - Input Parameters :  int applicationId
	 * - Return Type :String[] 
	 * - Throws : UserException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieval of email id and scheduled program id of an applicant according to applicantId
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public String[] getApplicantInfo(int applicationId) throws UserException {
		return applicantDAO.getApplicantInfo(applicationId);
	}
}