package com.uas.service;

import com.uas.bean.ParticipantBean;
import com.uas.dao.IParticipantDAO;
import com.uas.dao.ParticipantDAOImpl;
import com.uas.exception.UserException;

/**
 *  Author : Jitesh, Harshita, Sree Ramya
 *  Class Name : ParticipantServiceImpl 
 *  Package :com.uas.service 
 *  Date : December 09, 2017
 *  Version : 1.0
 */
public class ParticipantServiceImpl implements IParticipantService {
	IParticipantDAO participantDAO;
	
	
	public ParticipantServiceImpl() {
		super();
		participantDAO = new ParticipantDAOImpl();
	}


	/**************************************************************
	 * - Method Name : addParticipant(ParticipantBean participantBean, int applicationId, int scheduleId)
	 * - Input Parameters : ParticipantBean participantBean, int applicationId, int scheduleId
	 * - Return Type :boolean
	 * - Throws : UserException 
	 * - Author : Jitesh, Harshita, Sree Ramya
	 * - Creation Date : December 09, 2017 
	 * - Description : insert applicant to the participant table
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public boolean addParticipant(ParticipantBean participantBean, int applicationId, String scheduleId) throws UserException {
		
		return participantDAO.addParticipant(participantBean, applicationId, scheduleId);
	}

}