package com.uas.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.uas.bean.ApplicantBean;
import com.uas.bean.ProgramsOfferedBean;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.bean.UserBean;
import com.uas.dao.AdminDAOImpl;
import com.uas.dao.IAdminDAO;
import com.uas.exception.UserException;

/**
 *  Author : Gaurav, Pratyush, Arjun
 *  Class Name : AdminServiceImpl 
 *  Package :com.uas.service 
 *  Date : December 09, 2017
 */
public class AdminServiceImpl implements IAdminService {

	private IAdminDAO adminDAO;

	public AdminServiceImpl() {
		adminDAO = new AdminDAOImpl();
	}

	/**************************************************************
	 * - Method Name : isAuthenticated(UserBean userBean) 
	 * - Input Parameters :  UserBean userBean
	 * - Return Type :boolean 
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 09, 2017 
	 * - Description : Authenticate the user
	 * - Version : 1.0 
	 *************************************************************/
	@Override
	public boolean isAuthenticated(UserBean userBean) throws UserException {

		return adminDAO.isAuthenticated(userBean);
	}

	/**************************************************************
	 * - Method Name : deleteProgramOffered(String programName)
	 * - Input Parameters :  String programName
	 * - Return Type :boolean 
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 09, 2017 
	 * - Description : delete program offered according to program name
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public boolean deleteProgramOffered(String programName)
			throws UserException {
		return adminDAO.deleteProgramOffered(programName);
	}

	/**************************************************************
	 * - Method Name : addProgramOffered(ProgramsOfferedBean programsOfferedBean)
	 * - Input Parameters :  ProgramsOfferedBean programsOfferedBean
	 * - Return Type :boolean 
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 09, 2017 
	 * - Description : insert program offered
	 * - Version : 1.0 
	 *************************************************************/
	@Override
	public boolean addProgramOffered(ProgramsOfferedBean programsOfferedBean)
			throws UserException {

		return adminDAO.addProgramOffered(programsOfferedBean);
	}

	/**************************************************************
	 * - Method Name : viewProgramsScheduled()
	 * - Input Parameters :  
	 * - Return Type : List<ProgramsScheduledBean>
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieve all programs scheduled
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public List<ProgramsScheduledBean> viewProgramsScheduled()
			throws UserException {

		return adminDAO.viewProgramsScheduled();
	}

	/**************************************************************
	 * - Method Name : deleteProgramScheduled(String programId)
	 * - Input Parameters :  String programId
	 * - Return Type : boolean
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 09, 2017 
	 * - Description : delete programs scheduled according to program ID
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public boolean deleteProgramScheduled(String programId)
			throws UserException {

		return adminDAO.deleteProgramScheduled(programId);
	}

	/**************************************************************
	 * - Method Name : addProgramScheduled(ProgramsScheduledBean programsScheduledBean)
	 * - Input Parameters :  ProgramsScheduledBean programsScheduledBean
	 * - Return Type : boolean
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 09, 2017 
	 * - Description : insert new programs scheduled
	 * - Version : 1.0 
	 *************************************************************/
	@Override
	public boolean addProgramScheduled(
			ProgramsScheduledBean programsScheduledBean) throws UserException {

		return adminDAO.addProgramScheduled(programsScheduledBean);
	}

	/**************************************************************
	 * - Method Name : viewListOfApplicants()
	 * - Input Parameters :  
	 * - Return Type : List<ApplicantBean>
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieve list of applicants
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public List<ApplicantBean> viewListOfApplicants() throws UserException {

		return adminDAO.viewListOfApplicants();

	}

	/**************************************************************
	 * - Method Name : isValidProgramName(String programName)
	 * - Input Parameters :  String programName
	 * - Return Type : boolean
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 16, 2017 
	 * - Description : Validating program name
	 * - Version : 1.0
	 *************************************************************/
	public boolean isValidProgramName(String programName) throws UserException {
		boolean isValid = false;

		String regx = "^[\\p{L} .'-]+$";

		Pattern pattern = Pattern.compile(regx, Pattern.UNICODE_CASE);
		Matcher matcher = pattern.matcher(programName);
		isValid = matcher.matches();

		if (!isValid) {
			throw new UserException(
					"Name must start with Capital and must contains only letters");
		}
		return isValid;
	}

	/**************************************************************
	 * - Method Name : isValidDescription(String description)
	 * - Input Parameters :  String description
	 * - Return Type : boolean
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 16, 2017 
	 * - Description : Validating program description
	 * - Version : 1.0
	 *************************************************************/
	public boolean isValidDescription(String description) throws UserException {
		boolean isValid = false;

		if (description.length() <= 40) {
			isValid = true;

		}

		if (!isValid) {
			throw new UserException("Exceeding the limit more than 40 char");
		}
		return isValid;
	}

	/**************************************************************
	 * - Method Name : isValidEligibility(String applicantEligibility)
	 * - Input Parameters :  String applicantEligibility
	 * - Return Type : boolean
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 16, 2017 
	 * - Description : Validating applicant eligibility
	 * - Version : 1.0
	 *************************************************************/
	public boolean isValidEligibility(String applicantEligibility)
			throws UserException {
		boolean isValid = false;

		if (applicantEligibility.length() <= 40) {
			isValid = true;

		}

		if (!isValid) {
			throw new UserException("Exceeding the limit more than 40 char");
		}
		return isValid;
	}

	/**************************************************************
	 * - Method Name : isValidDuration(byte duration)
	 * - Input Parameters :  byte duration
	 * - Return Type : boolean
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 16, 2017 
	 * - Description : Validating duration entered
	 * - Version : 1.0
	 *************************************************************/
	public boolean isValidDuration(byte duration) throws UserException {
		boolean isValid = false;
		if (duration > 0) {
			isValid = true;
		} else {
			throw new UserException(
					"Duration cannot be negative! kindly, enter again.");
		}
		return isValid;
	}

	/**************************************************************
	 * - Method Name : isValidDegreeOffered(String degreeOffered)
	 * - Input Parameters :  String degreeOffered
	 * - Return Type : boolean
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 16, 2017 
	 * - Description : Validating degree Offered
	 * - Version : 1.0
	 *************************************************************/
	public boolean isValidDegreeOffered(String degreeOffered)
			throws UserException {
		boolean isValid = false;

		if (degreeOffered.length() <= 10) {
			isValid = true;

		}

		if (!isValid) {
			throw new UserException(
					"Exceeding the DEGREE_CERTIFICATE_OFFERED limit more than 10 char");
		}
		return isValid;
	}
	
	/**************************************************************
	 * - Method Name : checkValidProgramId(String programId)
	 * - Input Parameters :  String programId
	 * - Return Type : boolean
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 16, 2017 
	 * - Description : Validating program ID
	 * - Version : 1.0
	 *************************************************************/
	public boolean checkValidProgramId(String programId) throws UserException{
		boolean isValid = false;
			
			String pattern ="[A-Z]{2}[0-9]{0,}";
		  
		  Pattern ptn = Pattern.compile(pattern);
		  Matcher matcher = ptn.matcher(programId);
		  isValid = matcher.matches();
		
		  if (!isValid) {
				throw new UserException(
						"Name must start with Capital and must contains only letters");
			}
			
		return isValid;
	}
	
	/**************************************************************
	 * - Method Name : checkValidCity(String city)
	 * - Input Parameters :  String city
	 * - Return Type : boolean
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 16, 2017 
	 * - Description : Validating program city
	 * - Version : 1.0
	 *************************************************************/
	public boolean checkValidCity(String city) throws UserException{
		boolean isValid = false;

		String regx = "^[\\p{L} .'-]+$";


		Pattern pattern = Pattern.compile(regx,Pattern.UNICODE_CASE);
	    Matcher matcher = pattern.matcher(city);
		isValid = matcher.matches();

		if (!isValid) {
			throw new UserException(
					"city must start with Capital and must contains only letters");
		}
		return isValid;
	}
	
	/**************************************************************
	 * - Method Name : checkValidState(String state)
	 * - Input Parameters :  String state
	 * - Return Type : boolean
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 16, 2017 
	 * - Description : Validating program state
	 * - Version : 1.0
	 *************************************************************/
	public boolean checkValidState(String state) throws UserException{
		boolean isValid = false;

		String regx = "^[\\p{L} .'-]+$"; 


		Pattern pattern = Pattern.compile(regx,Pattern.UNICODE_CASE);
	    Matcher matcher = pattern.matcher(state);
		isValid = matcher.matches();

		if (!isValid) {
			throw new UserException(
					"state must start with Capital and must contains only letters");
		}
		return isValid;
	}
	
	/**************************************************************
	 * - Method Name : checkValidZipcode(int zipCode)
	 * - Input Parameters :  int zipCode
	 * - Return Type : boolean
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 16, 2017 
	 * - Description : Validating zipcode
	 * - Version : 1.0
	 *************************************************************/
	public boolean checkValidZipcode(int zipCode)
			throws UserException {
		boolean isValid = false;
		String zip = Integer.toString(zipCode) ;
		if(zip.length() == 6){
			isValid = true;
			
		}

		if (!isValid) {
			throw new UserException(
					"Zipcode cannot be more or less than 6 digits");
		}
		return isValid;
	}
	
	/**************************************************************
	 * - Method Name : checkValidSession(byte session)
	 * - Input Parameters :  byte session
	 * - Return Type : boolean
	 * - Throws : UserException 
	 * - Author : Gaurav, Pratyush, Arjun
	 * - Creation Date : December 16, 2017 
	 * - Description : Validating session of program
	 * - Version : 1.0
	 *************************************************************/
	public boolean checkValidSession(byte session) throws UserException{
		boolean isValid = false;
		if(session>0){
			isValid = true;
		}else{
			throw new UserException("Session must be positive integer");
		}
		
		return isValid;
	}

}