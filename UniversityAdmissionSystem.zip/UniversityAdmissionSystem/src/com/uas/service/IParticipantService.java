package com.uas.service;

import com.uas.bean.ParticipantBean;
import com.uas.exception.UserException;

public interface IParticipantService {
	public boolean addParticipant(ParticipantBean participantBean, int applicationId, String scheduleId) throws UserException;
}
