package com.uas.service;

import java.time.LocalDate;
import java.util.List;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.UserBean;
import com.uas.dao.IMacDAO;
import com.uas.dao.MacDaoImpl;
import com.uas.exception.UserException;

/**
 *  Author : Jitesh, Harshita, Sree Ramya
 *  Class Name : MacServiceImpl 
 *  Package :com.uas.service 
 *  Date : December 09, 2017
 *  Version: 1.0 
 */
public class MacServiceImpl implements IMacService {

	private IMacDAO macDao = new MacDaoImpl();
	
	/**************************************************************
	 * - Method Name : isAuthenticated(UserBean userBean) 
	 * - Input Parameters : UserBean userBean 
	 * - Return Type :boolean 
	 * - Throws : UserException 
	 * - Author : Jitesh, Harshita, Sree Ramya
	 * - Creation Date : December 09, 2017 
	 * - Description : Authenticate the user
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public boolean isAuthenticated(UserBean userBean)
			throws UserException {
		
		return macDao.isAuthenticated(userBean);
				
	}

	/**************************************************************
	 * - Method Name : viewAllStudentDetails(String Scheduled_program_id)
	 * - Input Parameters : String Scheduled_program_id 
	 * - Return Type :List<ApplicantBean>
	 * - Throws : UserException 
	 * - Author : Jitesh, Harshita, Sree Ramya
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieve list of applicants based on scheduled program ID
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public List<ApplicantBean> viewAllStudentDetails(String Scheduled_program_id) throws UserException{
		
		return macDao.viewListOfApplicants(Scheduled_program_id);
	}

	/**************************************************************
	 * - Method Name : scheduleInterviewDate(int applicationId,Application_Status status, LocalDate dateOfInterview)
	 * - Input Parameters : int applicationId,Application_Status status, LocalDate dateOfInterview
	 * - Return Type :boolean
	 * - Throws : UserException 
	 * - Author : Jitesh, Harshita, Sree Ramya
	 * - Creation Date : December 09, 2017 
	 * - Description : update status of applicant and assign date of interview to the applicant
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public boolean scheduleInterviewDate(int applicationId, Application_Status status, LocalDate dateOfInterview) throws UserException{
		
		return macDao.scheduleInterviewDate(applicationId, status, dateOfInterview);
	}

	/**************************************************************
	 * - Method Name : enrollApplicant(int applicationId, Application_Status status)
	 * - Input Parameters : int applicationId, Application_Status status
	 * - Return Type :boolean
	 * - Throws : UserException 
	 * - Author : Jitesh, Harshita, Sree Ramya
	 * - Creation Date : December 09, 2017 
	 * - Description : update status of applicant and enroll it for the program
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public boolean enrollApplicant(int applicationId, Application_Status status)
			throws UserException {
		return macDao.enrollApplicant(applicationId, status);
	}

}