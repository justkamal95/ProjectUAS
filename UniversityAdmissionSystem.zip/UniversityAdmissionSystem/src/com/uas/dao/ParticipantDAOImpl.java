package com.uas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.uas.bean.ParticipantBean;
import com.uas.exception.UserException;
import com.uas.util.DBConnection;

/**
 *  Author : Jitesh, Harshita, Sree Ramya
 *  Class Name : ApplicantDAOImpl 
 *  Package :com.uas.dao 
 *  Date : December 09, 2017
 *  Version : 1.0
 */
public class ParticipantDAOImpl implements IParticipantDAO {

	/**************************************************************
	 * - Method Name : addParticipant(ParticipantBean participantBean, int applicationId, int scheduleId)
	 * - Input Parameters : ParticipantBean participantBean, int applicationId, int scheduleId
	 * - Return Type :boolean
	 * - Throws : UserException 
	 * - Author : Jitesh, Harshita, Sree Ramya
	 * - Creation Date : December 09, 2017 
	 * - Description : insert applicant to the participant table
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public boolean addParticipant(ParticipantBean participantBean, int applicationId, String scheduleId) throws UserException {
		try(Connection conn = DBConnection.getInstance().getConnection();) {
			PreparedStatement preparedStatement = conn.prepareStatement(ParticipantQueryMapper.ADD_PARTICIPANT);
			preparedStatement.setString(1, participantBean.getRollNo());
			preparedStatement.setString(2, participantBean.getEmailId());
			preparedStatement.setInt(3, applicationId);
			preparedStatement.setString(4, scheduleId);
			if(preparedStatement.executeUpdate()>0)
				return true;
		} catch (SQLException e) {
			throw new UserException("Invalid details");
		}
		return false;
	}

}
