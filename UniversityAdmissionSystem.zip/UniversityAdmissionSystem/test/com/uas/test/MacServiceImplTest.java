package com.uas.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.time.LocalDate;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.UserBean;
import com.uas.bean.UserRole;
import com.uas.exception.UserException;
import com.uas.service.IMacService;
import com.uas.service.MacServiceImpl;

public class MacServiceImplTest {

	IMacService macService;
	
	@Before
	public void setUp() throws Exception {
		macService = new MacServiceImpl();
	}

	@After
	public void tearDown() throws Exception {
		macService = null;
	}

	@Test
	public final void testIsAuthenticated() {
		UserBean userBean = new UserBean("Test","Test@123",UserRole.MAC);
		try {
			boolean isAuth = macService.isAuthenticated(userBean);
			assertEquals(true,isAuth);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

	@Test
	public final void testViewAllStudentDetails() {
		try {
			List<ApplicantBean> applicantList = macService.viewAllStudentDetails("1");
			assertTrue(applicantList.size()>0);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

	
	@Test
	public final void testScheduleInterviewDate() {
		try {
			boolean isUpdated = macService.scheduleInterviewDate(1020, Application_Status.ACCEPTED, LocalDate.now());
			assertEquals(true, isUpdated);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testEnrollApplicant() {
		try {
			boolean isUpdated = macService.enrollApplicant(1020, Application_Status.CONFIRMED);
			assertEquals(true, isUpdated);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

}
