package com.uas.test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.time.LocalDate;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.exception.UserException;
import com.uas.service.ApplicantServiceImpl;

public class ApplicantServiceImplTest {

	ApplicantServiceImpl applicantServiceImpl;

	@Before
	public void setUp() throws Exception {
		applicantServiceImpl = new ApplicantServiceImpl();
	}

	@After
	public void tearDown() throws Exception {
		applicantServiceImpl = null;
	}

	@Test
	public final void testViewPrograms() {
		try {
			List<ProgramsScheduledBean> programList = applicantServiceImpl
					.viewPrograms();
			assertTrue(programList.size() > 0);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

	@Test
	public final void testInsertApplicant() {
		ApplicantBean applicantBean = new ApplicantBean();
		applicantBean.setFullName("Test");
		applicantBean.setDateOfBirth(LocalDate.now());
		applicantBean.setEmailId("test@test.com");
		applicantBean.setGoals("Developer");
		applicantBean.setHighestQualification("Graduate");
		applicantBean.setMarksObtained(85);
		String programName = "BTECH";
		try {
			int applicantID = applicantServiceImpl.insertApplicant(
					applicantBean, programName);
			assertTrue(applicantID > 1000);
		} catch (UserException e) {
			e.printStackTrace();
		}

	}

	@Test
	public final void testViewStatus() {
		try {
			Application_Status status = applicantServiceImpl.viewStatus(1020);
			assertEquals(Application_Status.APPLIED, status);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

	@Test
	public final void testIsValidName() {
		try {
			boolean isValid = applicantServiceImpl.isValidName("Test");
			assertEquals(true, isValid);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}
	
	@Test 
	public final void testIsValidMarksObtained() {
		try {
			boolean isValid = applicantServiceImpl.isValidMarksObtained(5);
			assertEquals(true, isValid);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}
	
	@Test 
	public final void testIsValidMail() { 
		try {
			boolean isValid = applicantServiceImpl.isValidMail("a@a.com");
			assertEquals(true, isValid);
		} catch (UserException e) {
			e.printStackTrace();
		}
	 } 
	 @Test 
	 public final void testGetApplicantInfo() {
		 try {
			 String[] data = applicantServiceImpl.getApplicantInfo(1020);
			 assertEquals("a@a.com",data[0]);
			 assertEquals("1",data[1]);
		} catch (UserException e) {
			e.printStackTrace();
		}
	 }
	 
}
