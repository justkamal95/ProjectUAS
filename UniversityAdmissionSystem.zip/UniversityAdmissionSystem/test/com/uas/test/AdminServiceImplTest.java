package com.uas.test;
import static org.junit.Assert.*;

import java.time.LocalDate;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.uas.bean.ApplicantBean;
import com.uas.bean.ProgramsOfferedBean;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.bean.UserBean;
import com.uas.bean.UserRole;
import com.uas.exception.UserException;
import com.uas.service.AdminServiceImpl;

public class AdminServiceImplTest {

	AdminServiceImpl adminService;
	
	@Before
	public void setUp() throws Exception {
		adminService  = new AdminServiceImpl();
	}

	@After
	public void tearDown() throws Exception {
		adminService = null;
	}

	@Test
	public final void testIsAuthenticated() {
		UserBean userBean = new UserBean("Admin","Test@123",UserRole.ADMIN);
		try {
			boolean isAuth = adminService.isAuthenticated(userBean);
			assertEquals(true,isAuth);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

	@Test
	public final void testDeleteProgramOffered() {
		try {
			boolean isDeleted = adminService.deleteProgramOffered("MTECH");
			assertEquals(true, isDeleted);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

	
	@Test
	public final void testAddProgramOffered() {
		ProgramsOfferedBean programsOfferedBean = new ProgramsOfferedBean("MTECH","Post Graduate","Graduate",(byte)24,"PG");
		try {
			boolean isAdded = adminService.addProgramOffered(programsOfferedBean);
			assertEquals(true, isAdded);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

	
	@Test
	public final void testViewProgramsScheduled() {
		try {
			List<ProgramsScheduledBean> programList = adminService.viewProgramsScheduled();
			assertTrue(programList.size()>0);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

	
	@Test
	public final void testDeleteProgramScheduled() {
		try {
			boolean isDeleted = adminService.deleteProgramScheduled("1");
			assertEquals(true, isDeleted);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}
	
	@Test
	public final void testAddProgramScheduled() {
		ProgramsOfferedBean programsOfferedBean = new ProgramsOfferedBean();
		programsOfferedBean.setProgramName("MBA");
		ProgramsScheduledBean programsScheduledBean = new ProgramsScheduledBean("2","Banagalore","Karanataka",302022,LocalDate.now(),LocalDate.of(2018, 03, 22),(byte)24,programsOfferedBean);
		try {
			boolean isInserted = adminService.addProgramScheduled(programsScheduledBean);
			assertEquals(true, isInserted);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

	
	@Test
	public final void testViewListOfApplicants() {
		try {
			List<ApplicantBean> applicantList = adminService.viewListOfApplicants();
			assertTrue(applicantList.size()>0);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

	
	@Test
	public final void testIsValidProgramName() {
		try {
			boolean isValid = adminService.isValidProgramName("MBA");
			assertEquals(true, isValid);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

	
	@Test
	public final void testIsValidDescription() {
		try {
			boolean isValid = adminService.isValidDescription("Post Graduation");
			assertEquals(true, isValid);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

	@Test
	public final void testIsValidEligibility() {
		try {
			boolean isValid = adminService.isValidEligibility("Graduate");
			assertEquals(true, isValid);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

	@Test
	public final void testIsValidDuration() {
		try {
			boolean isValid = adminService.isValidDuration((byte)24);
			assertEquals(true, isValid);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

	@Test
	public final void testIsValidDegreeOffered() {
		try {
			boolean isValid = adminService.isValidDegreeOffered("Masters");
			assertEquals(true, isValid);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

	@Test
	public final void testCheckValidProgramId() {
		try {
			boolean isValid = adminService.checkValidProgramId("3");
			assertEquals(true, isValid);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

	@Test
	public final void testCheckValidCity() {
		try {
			boolean isValid = adminService.checkValidCity("Mumbai");
			assertEquals(true, isValid);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

	@Test
	public final void testCheckValidState() {
		try {
			boolean isValid = adminService.checkValidState("Maharastra");
			assertEquals(true, isValid);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

	@Test
	public final void testCheckValidZipcode() {
		try {
			boolean isValid = adminService.checkValidZipcode(302026);
			assertEquals(true, isValid);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

	@Test
	public final void testCheckValidSession() {
		try {
			boolean isValid = adminService.checkValidSession((byte)24);
			assertEquals(true, isValid);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

}
