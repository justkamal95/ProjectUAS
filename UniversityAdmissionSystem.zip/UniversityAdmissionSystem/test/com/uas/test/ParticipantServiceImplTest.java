package com.uas.test;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;
import com.uas.bean.ParticipantBean;
import com.uas.exception.UserException;
import com.uas.service.IParticipantService;
import com.uas.service.ParticipantServiceImpl;

public class ParticipantServiceImplTest {

	IParticipantService participantService;
	
	@Before
	public void setUp() throws Exception {
		participantService = new ParticipantServiceImpl();
	}

	@After
	public void tearDown() throws Exception {
		participantService=null;
	}

	@Test
	public final void testAddParticipant() {
		ParticipantBean participantBean = new ParticipantBean();
		participantBean.setRollNo("10072");
		participantBean.setEmailId("test@test.com");
		
		try {
			boolean isInserted = participantService.addParticipant(participantBean, 1020, "BS123");
			assertEquals(true, isInserted);
		} catch (UserException e) {
			e.printStackTrace();
		}
	}

}
