package com.uas.exception;

public class UserException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5168136240377046837L;

	public UserException(String message) {
		super(message);
	}
	
}
