package com.uas.dao;

public interface AdminQueryMapper {
	public static final String IS_AUTHENTICATED="SELECT login_id,password,role FROM Users WHERE login_id=? AND password=?";
	
	//PROGRAMS OFFERED
	public static final String DELETE_PROGRAM_OFFERED = "DELETE FROM Programs_Offered WHERE ProgramName=?";
	public static final String ADD_PROGRAM_OFFERED ="INSERT INTO Programs_Offered VALUES(?,?,?,?,?)";
	
	//PROGRAMS SCEHDULED
	public static final String DELETE_PROGRAM_SCHEDULED = "DELETE FROM Programs_Scheduled WHERE Scheduled_program_id=?";
	public static final String ADD_PROGRAM_SCHEDULED = "INSERT INTO Programs_Scheduled VALUES(?,?,?,?,?,?,?)";
	public static final String VIEW_PROGRAM_SCHEDULED = "SELECT Scheduled_program_id,ProgramName,City,State,Zipcode,start_date,end_date,sessions_per_week FROM Programs_Scheduled";
	
	//APPLICANTS
	public static final String VIEW_APPLICANTS = 
			"SELECT Application_id,full_name,date_of_birth,highest_qualification,marks_obtained,goals,email_id,Scheduled_program_id,status,Date_Of_Interview from APPLICATION";
}