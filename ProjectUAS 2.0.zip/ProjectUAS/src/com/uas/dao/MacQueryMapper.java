package com.uas.dao;

public interface MacQueryMapper {
	
	public static final String IS_AUTHENTICATED = "SELECT login_id, password, role FROM users";
	public static final String VIEW_APPLICANTS = 
			"SELECT Application_id,full_name,date_of_birth,highest_qualification,marks_obtained,goals,email_id,Scheduled_program_id,status,Date_Of_Interview from APPLICATION WHERE Scheduled_program_id = ?";
	public static final String UPDATE_STATUS = "UPDATE APPLICATION SET status=? , Date_Of_Interview=? "
											+ "WHERE Application_id=?";

}
