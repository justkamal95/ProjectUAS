package com.uas.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.uas.bean.ParticipantBean;
import com.uas.exception.UserException;
import com.uas.util.DBConnection;

public class ParticipantDAOImpl implements IParticipantDAO {

	@Override
	public boolean addParticipant(ParticipantBean participantBean) throws UserException {
		try(Connection conn = DBConnection.getInstance().getConnection();) {
			PreparedStatement preparedStatement = conn.prepareStatement(ParticipantQueryMapper.ADD_PARTICIPANT);
			preparedStatement.setString(1, participantBean.getRollNo());
			preparedStatement.setString(2, participantBean.getEmailId());
			if(preparedStatement.executeUpdate()>0)
				return true;
		} catch (SQLException e) {
			throw new UserException(e.getMessage());
		}
		return false;
	}

}
