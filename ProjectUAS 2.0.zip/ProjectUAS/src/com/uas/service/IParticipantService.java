package com.uas.service;

import com.uas.bean.ParticipantBean;
import com.uas.exception.UserException;

public interface IParticipantService {
	public boolean addParticipant(ParticipantBean participantBean) throws UserException;
}
