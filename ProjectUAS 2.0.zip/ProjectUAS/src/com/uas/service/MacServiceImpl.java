package com.uas.service;

import java.time.LocalDate;
import java.util.List;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.UserBean;
import com.uas.dao.IMacDAO;
import com.uas.dao.MacDaoImpl;
import com.uas.exception.UserException;


public class MacServiceImpl implements IMacService {

	private IMacDAO macDao = new MacDaoImpl();
	
	@Override
	public boolean isAuthenticated(UserBean userBean)
			throws UserException {
		
		return macDao.isAuthenticated(userBean);
				
	}

	@Override
	public List<ApplicantBean> viewAllStudentDetails(String Scheduled_program_id) throws UserException{
		
		return macDao.viewListOfApplicants(Scheduled_program_id);
	}

	@Override
	public boolean scheduleInterviewDate(int applicationId, Application_Status status, LocalDate dateOfInterview) throws UserException{
		
		return macDao.scheduleInterviewDate(applicationId, status, dateOfInterview);
	}

}
