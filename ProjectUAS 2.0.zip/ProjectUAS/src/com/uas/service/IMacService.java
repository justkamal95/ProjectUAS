package com.uas.service;



import java.sql.SQLException;
import java.util.List;

import com.uas.bean.ApplicantBean;
import com.uas.exception.CustomException;


public interface IMacService {
	
	public boolean isAuthenticated(String loginId, String pass, String role) throws CustomException, SQLException;

	
	public List<ApplicantBean> viewAllStudentDetails(String Scheduled_program_id) throws CustomException,SQLException;

	
	public boolean updateStatus(int applicationId, String status) throws CustomException , SQLException;
}
