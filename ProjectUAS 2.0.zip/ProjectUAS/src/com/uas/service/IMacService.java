package com.uas.service;



import java.time.LocalDate;
import java.util.List;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.UserBean;
import com.uas.exception.UserException;


public interface IMacService {
	
	public boolean isAuthenticated(UserBean userBean) throws UserException;

	
	public List<ApplicantBean> viewAllStudentDetails(String Scheduled_program_id) throws UserException;

	
	public boolean scheduleInterviewDate(int applicationId, Application_Status status, LocalDate dateOfInterview) throws UserException;
}
