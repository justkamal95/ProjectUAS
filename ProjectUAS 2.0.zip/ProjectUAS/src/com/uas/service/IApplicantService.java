package com.uas.service;

import java.util.List;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.exception.UserException;

public interface IApplicantService {

	public List<ProgramsScheduledBean> viewPrograms() throws UserException;
	public int insertApplicant(ApplicantBean applicantBean,String programName) throws UserException;
	public Application_Status viewStatus(int applicantId) throws UserException;
	public String getApplicantInfo(int applicationId) throws UserException;
}
