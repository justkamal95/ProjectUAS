package com.uas.service;

import com.uas.bean.ParticipantBean;
import com.uas.dao.IParticipantDAO;
import com.uas.dao.ParticipantDAOImpl;
import com.uas.exception.UserException;

public class ParticipantServiceImpl implements IParticipantDAO {
	IParticipantDAO participantDAO;
	
	
	public ParticipantServiceImpl() {
		super();
		participantDAO = new ParticipantDAOImpl();
	}


	@Override
	public boolean addParticipant(ParticipantBean participantBean) throws UserException {
		
		return participantDAO.addParticipant(participantBean);
	}

}
