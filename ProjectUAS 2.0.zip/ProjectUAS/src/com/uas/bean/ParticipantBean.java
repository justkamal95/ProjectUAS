package com.uas.bean;

public class ParticipantBean {
	private String rollNo;
	private String emailId;
	private ApplicantBean applicantBean;
	private ProgramsScheduledBean programsScheduledBean;
	
	public ParticipantBean() {
		super();
	}
	
	public ParticipantBean(String rollNo, String emailId) {
		super();
		this.rollNo = rollNo;
		this.emailId = emailId;
	}

	public ParticipantBean(String rollNo, String emailId,
			ApplicantBean applicantBean,
			ProgramsScheduledBean programsScheduledBean) {
		super();
		this.rollNo = rollNo;
		this.emailId = emailId;
		this.applicantBean = applicantBean;
		this.programsScheduledBean = programsScheduledBean;
	}

	public String getRollNo() {
		return rollNo;
	}

	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public ApplicantBean getApplicantBean() {
		return applicantBean;
	}

	public void setApplicantBean(ApplicantBean applicantBean) {
		this.applicantBean = applicantBean;
	}

	public ProgramsScheduledBean getProgramsScheduledBean() {
		return programsScheduledBean;
	}

	public void setProgramsScheduledBean(ProgramsScheduledBean programsScheduledBean) {
		this.programsScheduledBean = programsScheduledBean;
	}

	@Override
	public String toString() {
		return "ParticipantBean [rollNo=" + rollNo + ", emailId=" + emailId
				+ ", applicantBean=" + applicantBean
				+ ", programsScheduledBean=" + programsScheduledBean + "]";
	}
	
	
}
