package com.uas.bean;

public class ProgramsOfferedBean implements IPrograms{
	
	private String programName; //primary key
	private String description;
	private String applicantEligibility;
	private byte duration;
	private String degreeOffered;
	
	public ProgramsOfferedBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ProgramsOfferedBean(String programName, String description,
			String applicantEligibility, byte duration, String degreeOffered) {
		super();
		this.programName = programName;
		this.description = description;
		this.applicantEligibility = applicantEligibility;
		this.duration = duration;
		this.degreeOffered = degreeOffered;
	}
	public String getProgramName() {
		return programName;
	}
	public void setProgramName(String programName) {
		this.programName = programName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getApplicantEligibility() {
		return applicantEligibility;
	}
	public void setApplicantEligibility(String applicantEligibility) {
		this.applicantEligibility = applicantEligibility;
	}
	public byte getDuration() {
		return duration;
	}
	public void setDuration(byte duration) {
		this.duration = duration;
	}
	public String getDegreeOffered() {
		return degreeOffered;
	}
	public void setDegreeOffered(String degreeOffered) {
		this.degreeOffered = degreeOffered;
	}
	
	@Override
	public String toString() {
		return "ProgramsOfferedBean [programName=" + programName
				+ ", description=" + description + ", applicantEligibility="
				+ applicantEligibility + ", duration=" + duration
				+ ", degreeOffered=" + degreeOffered + "]";
	}
	
}
