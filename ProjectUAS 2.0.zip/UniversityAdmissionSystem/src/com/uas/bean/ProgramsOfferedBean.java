package com.uas.bean;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

/**
 * Author : KAMAL, GUNJAN Class Name : ProgramsOfferedBean Package :
 * com.uas.bean Date : November 27, 2017 Version : 1.1
 */
@Entity
@Table(name = "Programs_Offered")
public class ProgramsOfferedBean {

	@Id
	@Column(name = "ProgramName", length = 5)
	private String programName;

	@Column(name = "description", length = 40)
	private String description;

	@Column(name = "applicant_eligibility", length = 40)
	private String applicantEligibility;

	@Column(name = "duration")
	private byte duration;

	@Column(name = "degree_certificate_offered", length = 10)
	private String degreeOffered;

	@OneToMany(mappedBy = "programsOfferedBean", cascade = CascadeType.ALL)
	private Set<ProgramsScheduledBean> programsScheduled = new HashSet<>();

	// Constructors
	public ProgramsOfferedBean() {
		super();
	}

	public ProgramsOfferedBean(String programName, String description,
			String applicantEligibility, byte duration, String degreeOffered,
			Set<ProgramsScheduledBean> programsScheduled) {
		super();
		this.programName = programName;
		this.description = description;
		this.applicantEligibility = applicantEligibility;
		this.duration = duration;
		this.degreeOffered = degreeOffered;
		this.programsScheduled = programsScheduled;
	}

	public String getProgramName() {
		return programName;
	}

	public void setProgramName(String programName) {
		this.programName = programName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getApplicantEligibility() {
		return applicantEligibility;
	}

	public void setApplicantEligibility(String applicantEligibility) {
		this.applicantEligibility = applicantEligibility;
	}

	public byte getDuration() {
		return duration;
	}

	public void setDuration(byte duration) {
		this.duration = duration;
	}

	public String getDegreeOffered() {
		return degreeOffered;
	}

	public void setDegreeOffered(String degreeOffered) {
		this.degreeOffered = degreeOffered;
	}

	public Set<ProgramsScheduledBean> getProgramsScheduled() {
		return programsScheduled;
	}

	public void setProgramsScheduled(
			Set<ProgramsScheduledBean> programsScheduled) {
		this.programsScheduled = programsScheduled;
	}
	
	public void addProgramSchedule(ProgramsScheduledBean programsScheduledBean) {
		programsScheduledBean.setProgramsOfferedBean(this);		//this will avoid nested cascade
		this.getProgramsScheduled().add(programsScheduledBean);
	}

}
