package com.uas.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.dao.IApplicantDAO;
import com.uas.exception.UserException;

/**
 * Author 		: KAMAL, GUNJAN 
 * Class Name 	: ApplicantServiceImpl 
 * Package 		: com.uas.service 
 * Date 		: December 09, 2017
 * Version : 1.0
 */
@Service
public class ApplicantServiceImpl implements IApplicantService {

	@Autowired
	private IApplicantDAO applicantDAO;	
	
	/**************************************************************
	 * - Method Name : viewPrograms() 
	 * - Input Parameters :  
	 * - Return Type :List<ProgramsScheduledBean> 
	 * - Throws : UserException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieval of programs offered along with programs scheduled
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public List<ProgramsScheduledBean> viewPrograms() throws UserException {
		List<ProgramsScheduledBean> programsList =  applicantDAO.viewPrograms();
		return programsList;
	}

	/**************************************************************
	 * - Method Name : insertApplicant(ApplicantBean applicantBean,String programName) 
	 * - Input Parameters :  ApplicantBean, String
	 * - Return Type :int 
	 * - Throws : UserException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 09, 2017 
	 * - Description : insert new applicant details
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public int insertApplicant(ApplicantBean applicantBean, String programId) throws UserException {
		applicantBean.setStatus(Application_Status.APPLIED);
		int applicantId = applicantDAO.insertApplicant(applicantBean, programId);
		return applicantId;
	}

	/**************************************************************
	 * - Method Name : viewStatus(int applicantId) 
	 * - Input Parameters :  int
	 * - Return Type :Application_Status 
	 * - Throws : UserException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieval of status of an applicant according to applicantId
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public Application_Status viewStatus(int applicantId) throws UserException {
		Application_Status status = applicantDAO.viewStatus(applicantId);
		return status;
	}
		
	/**************************************************************
	 * - Method Name : getApplicantInfo(int applicationId) 
	 * - Input Parameters :  int applicationId
	 * - Return Type :String[] 
	 * - Throws : UserException 
	 * - Author : KAMAL, GUNJAN
	 * - Creation Date : December 09, 2017 
	 * - Description : Retrieval of email id and scheduled program id of an applicant according to applicantId
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public String[] getApplicantInfo(int applicationId) throws UserException {
		return applicantDAO.getApplicantInfo(applicationId);
	}
}