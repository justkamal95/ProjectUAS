package com.uas.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.uas.bean.ApplicantBean;
import com.uas.bean.ParticipantBean;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.exception.UserException;

/**
 *  Author : Jitesh, Harshita, Sree Ramya
 *  Class Name : ApplicantDAOImpl 
 *  Package :com.uas.dao 
 *  Date : December 09, 2017
 *  Version : 1.0
 */
@Repository
@Transactional
public class ParticipantDAOImpl implements IParticipantDAO {

	@PersistenceContext
	private EntityManager entityManager;
	
	/**************************************************************
	 * - Method Name : addParticipant(ParticipantBean participantBean, int applicationId, int scheduleId)
	 * - Input Parameters : ParticipantBean participantBean, int applicationId, int scheduleId
	 * - Return Type :boolean
	 * - Throws : UserException 
	 * - Author : Jitesh, Harshita, Sree Ramya
	 * - Creation Date : December 09, 2017 
	 * - Description : insert applicant to the participant table
	 * - Version : 1.0
	 *************************************************************/
	@Override
	public boolean addParticipant(ParticipantBean participantBean, int applicationId, String scheduleId) throws UserException {
		boolean isInserted = false;
		ProgramsScheduledBean programsScheduledBean = new ProgramsScheduledBean();
		programsScheduledBean.setProgramId(scheduleId);
		ApplicantBean applicantBean = new ApplicantBean();
		applicantBean.setApplicationId(applicationId);
		participantBean.setProgramsScheduledBean(programsScheduledBean);
		participantBean.setApplicantBean(applicantBean);
		entityManager.persist(programsScheduledBean);
		
		return isInserted;
	}

}
