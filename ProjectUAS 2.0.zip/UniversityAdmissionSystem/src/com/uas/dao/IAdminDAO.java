package com.uas.dao;

import java.util.List;

import com.uas.bean.ApplicantBean;
import com.uas.bean.ProgramsOfferedBean;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.bean.UserBean;
import com.uas.exception.UserException;

public interface IAdminDAO {
	public UserBean isAuthenticated(UserBean userBean) throws UserException;
	
	//Programs Offered Features
	public boolean deleteProgramOffered(String programName) throws UserException;
	public boolean addProgramOffered(ProgramsOfferedBean programsOfferedBean) throws UserException;
	
	//Programs Offered Features
	public List<ProgramsScheduledBean> viewProgramsScheduled() throws UserException;
	public boolean deleteProgramScheduled(String programId) throws UserException;
	public boolean addProgramScheduled(ProgramsScheduledBean programsScheduledBean) throws UserException;
	
	//view applicant for status
	public List<ApplicantBean> viewListOfApplicants() throws UserException;
}
