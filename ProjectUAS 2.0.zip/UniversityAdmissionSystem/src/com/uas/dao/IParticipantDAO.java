package com.uas.dao;

import com.uas.bean.ParticipantBean;
import com.uas.exception.UserException;

public interface IParticipantDAO {
	public boolean addParticipant(ParticipantBean participantBean, int applicationId, String scheduleId) throws UserException;
}
