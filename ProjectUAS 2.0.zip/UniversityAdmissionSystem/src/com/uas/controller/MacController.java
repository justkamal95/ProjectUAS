package com.uas.controller;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.bean.UserBean;
import com.uas.bean.UserRole;
import com.uas.exception.UserException;
import com.uas.service.IApplicantService;
import com.uas.service.IMacService;

@Controller
public class MacController {
	
	@Autowired
	private IMacService macService;
	
	@Autowired
	private IApplicantService applicantService;
	
	@RequestMapping("showHomePage")
	public String showHomePage(){
		return ("index");
	}
	
	@RequestMapping(value="login", method = RequestMethod.POST)
	public ModelAndView authenticate(@RequestParam("loginId") String loginId, @RequestParam("password") String password){
		ModelAndView modelAndView = new ModelAndView();
		
		UserBean userBean = new UserBean(loginId, password, UserRole.MAC);
		
		try {
			boolean authenticated = macService.isAuthenticated(userBean);
			if(authenticated){
				modelAndView.setViewName("success");
				List<ProgramsScheduledBean> programList = macService.getAllProgramsSchedule();
				modelAndView.addObject("programList", programList);
			}else{
				modelAndView.setViewName("errorPage");
				modelAndView.addObject("message","Invalid credentials");
			}
		} catch (UserException e) {
			modelAndView.setViewName("errorPage");
			modelAndView.addObject("message", e.getMessage());
		}
		
		return modelAndView; 
	}
	
	@RequestMapping(value="selectedProgram", method = RequestMethod.POST)
	public ModelAndView showApplicants(@RequestParam("programId") String programId){
		ModelAndView modelAndView = new ModelAndView();
		try {
			List<ApplicantBean> applicantList = macService.viewAllStudentDetails(programId);
			if(applicantList.size()>0){
				modelAndView.setViewName("allApplicants");
				modelAndView.addObject("applicantList", applicantList);
			}else{
				modelAndView.setViewName("errorPage");
				modelAndView.addObject("message","No Applicant applied for this program");
			}
			
		} catch (UserException e) {
			modelAndView.setViewName("errorPage");
			modelAndView.addObject("message", e.getMessage());
		}
		return modelAndView;
	}
	
	@RequestMapping("updateStatus")
	public ModelAndView showUpdatePage(@RequestParam("applicantId") int applicantId, @RequestParam("status") String status,
			@RequestParam("programId") String programId, @RequestParam("email") String emailId){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("update");
		modelAndView.addObject("status", status);
		modelAndView.addObject("applicantId", applicantId);
		modelAndView.addObject("programId", programId);
		modelAndView.addObject("emailId", emailId);
		return modelAndView;
	}
	
	@RequestMapping("update")
	public ModelAndView updateStatus(@RequestParam("status") String status, @RequestParam("dateOfInterview") String dateOfInterview,@RequestParam("applicationId") int applicationId,
			@RequestParam("programId") String programId, @RequestParam("emailId") String emailId){
		ModelAndView modelAndView = new ModelAndView();
		DateFormat formatter = new SimpleDateFormat("dd/MM/yyyy");
		boolean isUpdated = false;
		try {
			if(dateOfInterview.equals("")||dateOfInterview.equals(null)){
				isUpdated = macService.scheduleInterviewDate(applicationId, Application_Status.valueOf(status), null);
			}else{
				isUpdated = macService.scheduleInterviewDate(applicationId, Application_Status.valueOf(status), formatter.parse(dateOfInterview));
			}
			if(isUpdated){
				List<ApplicantBean> applicantList = macService.viewAllStudentDetails(programId);
				if(applicantList.size()>0){
					modelAndView.setViewName("allApplicants");
					modelAndView.addObject("applicantList", applicantList);
				}else{
					modelAndView.setViewName("errorPage");
					modelAndView.addObject("message","No Applicant applied for this program");
				}
			}
		} catch (UserException e) {
			modelAndView.setViewName("errorPage");
			modelAndView.addObject("message", e.getMessage());
		} catch (ParseException e) {
			modelAndView.setViewName("errorPage");
			modelAndView.addObject("message", e.getMessage());
		}
		return modelAndView;
	}
	
	/*@RequestMapping("loginAsApplicant")
	public String showApplicantIndex(){
		return ("applicant");
	}*/
	
	@RequestMapping("viewPrograms")
	public ModelAndView showPrograms(){
		ModelAndView modelAndView = new ModelAndView();
		try {
			List<ProgramsScheduledBean> programList = applicantService.viewPrograms();
			System.out.println(programList);
			modelAndView.setViewName("allPrograms");
			modelAndView.addObject("programList", programList);
		} catch (UserException e) {
			modelAndView.setViewName("errorPage");
			modelAndView.addObject("message", e.getMessage());
		}
		return modelAndView;
	}
	
	@RequestMapping("apply")
	public ModelAndView showForm(@RequestParam("programId") String programId){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("applicationForm");
		modelAndView.addObject("programId", programId);
		return modelAndView;
	}
	
	@RequestMapping("submitForm")
	public ModelAndView submitForm(@ModelAttribute("applicant") ApplicantBean applicantBean,@RequestParam("programId") String programId,@RequestParam("birthDate") String birthDate){
		ModelAndView modelAndView = new ModelAndView();
		try {
			applicantBean.setDateOfBirth(new SimpleDateFormat("yyyy-MM-dd").parse(birthDate));
			int applicantId = applicantService.insertApplicant(applicantBean, programId);
			modelAndView.setViewName("submit");
			modelAndView.addObject("applicantId", applicantId);
		} catch (UserException | ParseException e) {
			modelAndView.setViewName("errorPage");
			modelAndView.addObject("message", e.getMessage());
		}
		return modelAndView;
	}
	
	@RequestMapping("viewStatus")
	public String getApplicationId(){
		return ("status");
	}
	
	@RequestMapping("getStatus")
	public ModelAndView getStatus(@RequestParam("applicationId") int applicationId){
		ModelAndView modelAndView = new ModelAndView();
		try {
			Application_Status status = applicantService.viewStatus(applicationId);
			modelAndView.setViewName("showStatus");
			modelAndView.addObject("status", status.name());
		} catch (UserException e) {
			modelAndView.setViewName("errorPage");
			modelAndView.addObject("message", e.getMessage());
		}
		return modelAndView;
	}
}
