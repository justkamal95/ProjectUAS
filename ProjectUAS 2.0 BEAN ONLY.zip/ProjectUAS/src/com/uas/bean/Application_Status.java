package com.uas.bean;

public enum Application_Status{
	APPLIED, ACCEPTED, REJECTED, CONFIRMED;
}
