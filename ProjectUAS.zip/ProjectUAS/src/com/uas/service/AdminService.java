package com.uas.service;

import java.util.List;

import com.uas.bean.ApplicantBean;
import com.uas.bean.ProgramsOfferedBean;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.dao.AdminDAOImpl;
import com.uas.dao.IAdminDAO;
import com.uas.exception.CustomException;

public class AdminService implements IAdminService {


	private IAdminDAO adminDAO;
	
	public AdminService() {
		adminDAO = new AdminDAOImpl();
	}
	@Override
	public boolean isAuthenticated(String loginId, String pass)
			throws CustomException {
		
		return adminDAO.isAuthenticated(loginId, pass);
	}

	@Override
	public boolean deleteProgramOffered(String programName)
			throws CustomException {
		return adminDAO.deleteProgramOffered(programName);
	}

	@Override
	public boolean addProgramOffered(ProgramsOfferedBean programsOfferedBean)
			throws CustomException {
		
		return adminDAO.addProgramOffered(programsOfferedBean);
	}

	@Override
	public List<ProgramsScheduledBean> viewProgramsScheduled()
			throws CustomException {
		
		return adminDAO.viewProgramsScheduled();
	}

	@Override
	public boolean deleteProgramScheduled(String programId)
			throws CustomException {
		
		return adminDAO.deleteProgramScheduled(programId);
	}

	@Override
	public boolean addProgramScheduled(
			ProgramsScheduledBean programsScheduledBean) throws CustomException {
		
		return adminDAO.addProgramScheduled(programsScheduledBean);
	}

	@Override
	public List<ApplicantBean> viewListOfApplicants() throws CustomException {
		
		return adminDAO.viewListOfApplicants();
		/*List<ApplicantBean> applicantList=adminDAO.viewListOfApplicants();
		return applicantList;*/
		
	}

	
	
	
	
	
	
}
