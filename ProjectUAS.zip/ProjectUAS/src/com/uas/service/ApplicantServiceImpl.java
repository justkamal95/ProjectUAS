package com.uas.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.uas.bean.ApplicantBean;
import com.uas.bean.Application_Status;
import com.uas.dao.ApplicantDAOImpl;
import com.uas.dao.IApplicantDAO;
import com.uas.exception.CustomException;

/**
 * Author 		: KUNAL, GUNJAN 
 * Class Name 	: ApplicantServiceImpl 
 * Package 		: com.uas.dto 
 * Date 		: December 09, 2017
 */
public class ApplicantServiceImpl implements IApplicantService {

	private IApplicantDAO applicantDAO;	
	
	public ApplicantServiceImpl() {
		applicantDAO = new ApplicantDAOImpl();
	}

	@Override
	public List<Object> viewPrograms() throws CustomException {
		List<Object> programsList =  applicantDAO.viewPrograms();
		return programsList;
	}

	@Override
	public int insertApplicant(ApplicantBean applicantBean, String programName) throws CustomException {
		int applicantId = applicantDAO.insertApplicant(applicantBean, programName);
		return applicantId;
	}

	@Override
	public Application_Status viewStatus(int applicantId) throws CustomException {
		Application_Status status = applicantDAO.viewStatus(applicantId);
		return status;
	}
	
	public boolean isValidName(String name) throws CustomException{
		boolean isValid = false;
		String pattern = "[A-Z]{1}[A-Za-z]{1,19}";		
		Pattern ptn = Pattern.compile(pattern);
		Matcher matcher = ptn.matcher(name);
		isValid = matcher.matches();
		if(!isValid){
			throw new CustomException("Invalid Name");
		}
		return isValid;
	}

	public boolean isValidMarksObtained(int marks) throws CustomException{
		boolean isValid = true;
		if(marks<=0){
			throw new CustomException("Invalid Marks");
		}
		return isValid;
	}
	
	public boolean isValidMail(String mail) throws CustomException{
		boolean isValid = false;
		String pattern = "[a-z0-9._%+-]+@[a-z0-9.-]+\\.[a-z]{2,3}$";		
		Pattern ptn = Pattern.compile(pattern);
		Matcher matcher = ptn.matcher(mail);
		isValid = matcher.matches();
		if(!isValid){
			throw new CustomException("Invalid Email ID");
		}
		return isValid;
	}
}
