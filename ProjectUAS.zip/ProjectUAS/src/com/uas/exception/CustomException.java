package com.uas.exception;

public class CustomException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 5168136240377046837L;

	public CustomException(String message) {
		super(message);
	}
	
}
