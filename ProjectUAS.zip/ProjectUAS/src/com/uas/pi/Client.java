package com.uas.pi;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

import com.uas.bean.ProgramsOfferedBean;
import com.uas.bean.ProgramsScheduledBean;
import com.uas.bean.UserBean;
import com.uas.bean.UserRole;

public class Client {

	static Scanner input = new Scanner(System.in);
	public static void main(String[] args) {
		
		
		UserBean user = new UserBean();
		
		System.out.println("Enter Your Role:");
		System.out.println("1. Admin");
		System.out.println("2. Member of Admission Committee");
		System.out.println("3. Applicant");
		System.out.println("4. Exit");
		UserRole role = UserRole.valueOf(input.nextLine());
		
		switch(role){
		
		case ADMIN:
			System.out.println("Enter Login ID: ");
			user.setLoginId(input.nextLine());
			System.out.println("Enter Password: ");
			user.setPassword(input.nextLine());
			user.setRole(role);
			if(true){		
				loginAsAdmin();
			}else{
				System.out.println("Enter valid credentials");
			}
			break;
			
		case MAC:
			System.out.println("Enter Login ID: ");
			user.setLoginId(input.nextLine());
			System.out.println("Enter Password: ");
			user.setPassword(input.nextLine());
			user.setRole(role);
			if(true){		//
				loginAsMAC();
			}else{
				System.out.println("Enter valid credentials");
			}
			break;
			
		case APPLICANT:
			loginAsApplicant();
			break;
		}

	}

	public static void loginAsAdmin(){
		System.out.println("Enter Choice");
		System.out.println("1. Programs Offered");
		System.out.println("2. Programs Scheduled");
		System.out.println("3. View Reports");
		int choice = Integer.parseInt(input.nextLine());
		
		switch(choice){
		
		case 1:
			programsOffered();
			break;
			
		case 2:
			programsSchedule();
			break;
			
		case 3:
			viewReports();
		}
	}
	
	public static void programsOffered(){
		System.out.println("Enter choice");
		System.out.println("1. Add program");
		System.out.println("2. Delete program");
		int response = Integer.parseInt(input.nextLine());
		if(response==1)
			addProgramOffered();
		else if(response==2)
			deleteProgramOffered();
		else
			System.out.println("blah");
	}
	
	public static void addProgramOffered(){
		ProgramsOfferedBean programsOfferedBean = new ProgramsOfferedBean();
		System.out.println("Enter program name");
		programsOfferedBean.setProgramName(input.next());
		System.out.println("Enter program description");
		programsOfferedBean.setDescription(input.next());
		System.out.println("Enter applicant eligibility");
		programsOfferedBean.setApplicantEligibility(input.next());
		System.out.println("Enter degree offered");
		programsOfferedBean.setDegreeOffered(input.next());
		System.out.println("Duration in weeks");
		programsOfferedBean.setDuration(input.nextByte());
		System.out.println(programsOfferedBean);
	}
	
	public static void deleteProgramOffered(){
		System.out.println("Enter program name");
		System.out.println("Program to be deleted: "+ input.next());
	}
	
	public static void programsSchedule(){
		System.out.println("Enter choice");
		System.out.println("1. Add program");
		System.out.println("2. Delete program");
		switch(input.nextInt()){
		case 1:	addProgramsScheduled();
				break;
		case 2:	deleteProgramsScheduled();
				break;		
		}
	}
	
	public static void addProgramsScheduled(){
		DateTimeFormatter dtf = DateTimeFormatter.ofPattern("dd/MM/yyyy");
		ProgramsScheduledBean programsScheduledBean = new ProgramsScheduledBean();
		System.out.println("Enter program to be scheduled");
		programsScheduledBean.setProgramId(input.next());
		System.out.println("Enter city where program is to be scheduled ");
		programsScheduledBean.setCity(input.next());
		System.out.println("Enter state");
		programsScheduledBean.setState(input.next());
		System.out.println("Enter ZipCode");
		programsScheduledBean.setZipCode(input.nextInt());
		System.out.println("Enter Start Date");
		programsScheduledBean.setStartDate(LocalDate.from(dtf.parse(input.next())));
		System.out.println("Enter End Date");
		programsScheduledBean.setEndDate(LocalDate.from(dtf.parse(input.next())));
		System.out.println("Enter session per week");
		programsScheduledBean.setSessionPerWeek(input.nextByte());
	}
	
	public static void deleteProgramsScheduled(){
		System.out.println("Enter program ID");
		System.out.println("Program to be deleted: "+ input.next());
	}
	
	public static void viewReports(){
		System.out.println("Enter choice");
		System.out.println("1. View Applicants");
		System.out.println("2. View Programs");
		switch(input.nextInt()){
		case 1: viewApplicants();
			break;
		case 2: viewPrograms();
			break;
		}
	}
	
	public static void viewApplicants(){
		
	}

	public static void viewPrograms(){
		
	}

	public static void loginAsMAC(){
		System.out.println("Enter choice");
		System.out.println("1. View Applicants");
		System.out.println("2. Accept/Reject Application");
		System.out.println("3. Update Status");
		switch(input.nextInt()){
		case 1: viewApplicants();
			break;
		case 2: updateApplicationStatus();
			break;
		case 3: updateApplicationStatus();
			break;
		}
	}
	
	public static void updateApplicationStatus(){
		
	}

	public static void loginAsApplicant(){
		System.out.println("Enter choice");
		System.out.println("1. View Applied Program Status");
		System.out.println("2. View Programs");
		switch(input.nextInt()){
		case 1: 
			System.out.println("Enter your Application ID: ");
			int applicantId = Integer.parseInt(input.nextLine());
			viewAppliedProgramStatus(applicantId);
			break;
		case 2:
			viewPrograms();
			break;
		}
	}
	
	public static void viewAppliedProgramStatus(int applicantId){
		
	}
	
}