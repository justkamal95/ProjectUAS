package com.uas.dao;

public interface MacQueryMapper {
	
	public static final String IS_AUTHENTICATED = "SELECT login_id, password, role FROM users";
	public static final String VIEW_APPLICANTS = "SELECT Application_id FROM APPLICATION_TBL WHERE Scheduled_program_id = ?";
	public static final String UPDATE_STATUS = "UPDATE application_tbl SET status=? WHERE Application_id=?";

}
